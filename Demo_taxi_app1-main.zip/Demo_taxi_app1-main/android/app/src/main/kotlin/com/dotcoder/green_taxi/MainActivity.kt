package com.dotcoder.green_taxi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
